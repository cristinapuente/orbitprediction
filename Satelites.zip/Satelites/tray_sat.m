%% Ajuste para el satélite
function tray_sat(X,Y)
% el argumento de esta función son las coordenadas X e Y de la tray. en forma de vector columna cada una
x = [X,Y]'; 
[z, a, b, alpha] = fitellipse(x, 'linear');
hF = figure();
hAx = axes('Parent', hF);
h = plotellipse(hAx, z, a, b, alpha, 'r.');
hold on
plotellipse(z, a, b, alpha)
plot(X,Y,'b*')
end