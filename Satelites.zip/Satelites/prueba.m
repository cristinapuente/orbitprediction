for i=1:1:27
a(i)=xynueva(i,1);
b(i)=xynueva(i,2);
end
c=b';
M=[-a.^2,-a,-c.^2,ones(size(a))];

p=M\c %coeficientes del polinomio

%y=[0,4.03,8.12,14.23,20.33,27.1,34.53,42.63,46.43]';
%M=[x.^2,x,ones(size(x))];
%p=M\y %coeficientes del polinomio

%hold on
figure
plot(a,c,'ro','markersize',4,'markerfacecolor','r')
z=polyval(p,a);
hold off
figure
plot(a,z,'ro','markersize',4,'markerfacecolor','r')
%plot(a,z)
%plot(a,z,'ro','markersize',4,'markerfacecolor','b')
%z=@(a) polyval(p,a);
%fplot(z,[a(1),a(end)])
%xlabel('x')
%ylabel('y')
%grid on
%title('Polinomio aproximador')
%hold off